"""SentryVerdict – Ausgabe-Datenstruktur"""
from dataclasses import dataclass


@dataclass
class SentryVerdict:
    """
    Vollständiges Ergebnis einer SENTRY-DVL-Prüfung.

    Attribute:
        status      : "FREIGEGEBEN" | "UNSICHER" | "ABGELEHNT"
        ist_sicher  : True nur bei FREIGEGEBEN
        konfidenz   : 0.0 – 1.0
        begruendung : Interne technische Erklärung (Logging)
        nutzer_msg  : Vordefinierte Meldung für den Nutzer
        checker     : Welcher Checker die Entscheidung ausgelöst hat
    """
    status:      str
    ist_sicher:  bool
    konfidenz:   float
    begruendung: str
    nutzer_msg:  str
    checker:     str

    MELDUNGEN = {
        "FREIGEGEBEN": None,
        "UNSICHER": (
            "Diese Antwort konnte nicht vollständig gegen den Quellkontext "
            "verifiziert werden. Bitte prüfen Sie das Originaldokument."
        ),
        "ABGELEHNT": (
            "Die generierte Antwort weicht vom Referenzkontext ab. "
            "Aus Sicherheitsgründen wird sie nicht angezeigt."
        ),
    }

    def get_nutzer_antwort(self, rohausgabe: str) -> str:
        """
        Haupt-Interface für Produktions-Code.

        Gibt die Originalantwort zurück (FREIGEGEBEN)
        oder eine deterministische Fallback-Meldung (UNSICHER/ABGELEHNT).
        """
        if self.status == "FREIGEGEBEN":
            return rohausgabe
        return self.MELDUNGEN[self.status]

    def __str__(self) -> str:
        return (
            f"[{self.status}] konfidenz={self.konfidenz:.2f} "
            f"checker={self.checker} | {self.begruendung}"
        )
