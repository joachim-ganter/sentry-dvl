# SENTRY-DVL

**Dokument-Verifikations-Layer für LLM-Ausgaben**

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20490643.svg)](https://doi.org/10.5281/zenodo.20490643)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

SENTRY-DVL prüft LLM-generierte Antworten gegen einen Referenzkontext
und blockiert abweichende, fehlerhafte oder widersprüchliche Ausgaben,
bevor sie dem Nutzer angezeigt werden.

Entwickelt für **High-Stakes-Systeme**: Medizin, Recht, Technik – überall wo
ein halluzinierter Wert echten Schaden anrichten kann.

## Prinzip: Safety-First

```
FP-Rate = 0,0%  ←  nicht verhandelbar
FN-Rate akzeptiert  ←  lieber blockieren als falsch freigeben
```

Ein `FREIGEGEBEN` bedeutet: **diese Antwort hat alle Prüfschichten bestanden.**

## Installation

```bash
pip install sentry-dvl
```

Oder direkt aus dem Quellcode:

```bash
git clone https://github.com/joachim-ganter/sentry-dvl
cd sentry-dvl
pip install -e .
```

## Schnellstart

```python
from sentry_dvl import SentryDVL

sentry = SentryDVL()

kontext = "Die maximale Traglast beträgt 250 kN."
antwort = "Die Traglast beträgt maximal 280 kN."

verdict = sentry.evaluieren(kontext, antwort)
ausgabe = verdict.get_nutzer_antwort(antwort)

print(verdict.status)    # ABGELEHNT
print(verdict.konfidenz) # 0.0
print(ausgabe)           # Sicherheits-Fallback-Meldung
```

## Die drei Status-Werte

| Status | Bedeutung | Nutzer sieht |
|---|---|---|
| `FREIGEGEBEN` | Antwort ist verifiziert | Die Originalantwort |
| `UNSICHER` | Grenzbereich, nicht sicher genug | Verifikationshinweis |
| `ABGELEHNT` | Klare Abweichung erkannt | Sicherheits-Fallback |

## Architektur

```
Kontext + LLM-Antwort
        ↓
┌──────────────────────────────────────────────┐
│  1. ZahlenChecker     (deterministisch)      │
│  2. EinheitenChecker  (deterministisch)      │  ← NEU in v1.2
│  3. NegationsChecker  (deterministisch)      │
│  4. SemantikChecker   (Embedding-Modell)     │
│  5. NLIChecker        (mDeBERTa, optional)   │
└──────────────────────────────────────────────┘
        ↓
  SentryVerdict
  .status / .konfidenz / .get_nutzer_antwort()
```

Jede Schicht löst Early-Exit aus — das NLI-Modell wird nur
aufgerufen wenn die vier günstigeren Checker bestanden haben.

### EinheitenChecker (v1.2)

Erkennt medizinisch-kritische Einheitenmutationen (Faktor-1000-Fehler):

| Mutation | Beispiel | Risiko |
|---|---|---|
| mg → mcg/µg | 500 mg → 500 mcg | Unterdosierung (Faktor 1000) |
| ml → µl | 2 ml → 2 µl | Unterdosierung (Faktor 1000) |
| mmol → µmol | 5 mmol → 5 µmol | Messwertfehler |
| g → mg | 1 g → 1 mg | Überdosierung (Faktor 1000) |

## CLI

```bash
# Einzelne Prüfung
sentry-dvl check --kontext "Traglast 250 kN" --antwort "Traglast 280 kN"

# Benchmark ausführen
sentry-dvl benchmark

# Ohne NLI-Modell (schneller, weniger Speicher)
sentry-dvl benchmark --kein-nli

# Version anzeigen
sentry-dvl info
```

## Konfiguration

```python
# Ohne NLI (schneller, ~560 MB weniger RAM)
sentry = SentryDVL(mit_nli=False)

# Eigene Schwellen
from sentry_dvl.checker import SemantikChecker
SemantikChecker.SCHWELLE_SICHER = 0.72
```

## Benchmark-Ergebnisse (v1.2, 50 Testfälle, 7 Kategorien)

```
Kategorien:
  A – Korrekte Antworten          (8 Fälle)
  B – Klare Fehler                (9 Fälle)
  C – ZahlenChecker Grenzfälle    (5 Fälle)
  D – NegationsChecker Grenzfälle (6 Fälle)
  E – NLI-Pflichtfälle            (7 Fälle)
  F – Paraphrase-Grenzfälle       (8 Fälle)
  G – EinheitenChecker            (7 Fälle)  ← NEU

Ziel: FP-Rate = 0,0% | Präzision = 100,0%
```

## Zitation

```bibtex
@misc{ganter2025sentrydvl,
  author    = {Ganter, JoAchim},
  title     = {SENTRY-DVL: Cascaded Hybrid Guardrail Architecture
               for LLM Fact-Verification},
  year      = {2025},
  doi       = {10.5281/zenodo.20490643},
  publisher = {Zenodo}
}
```

## Lizenz

MIT License – Copyright (c) 2025 JoAchim Ganter
